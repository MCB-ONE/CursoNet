﻿using BussinesLogic.Data;
using Core.Entities;
using Core.Interfaces;
using Microsoft.EntityFrameworkCore;

namespace BussinesLogic.Logic
{ 
    // Clse generica que implementa la interfaz del repositorio genérico
    public class GenericRepository<T> : IGenericRepository<T> where T: BaseEntity
    {
        private readonly UniversityDBContext _context;  

        public GenericRepository(UniversityDBContext context)
        {
            _context = context;
        }

        //private bool EntitiExist(int id)
        //{
        //    return (_context.Users?.Any(entity => entity.Id == id)).GetValueOrDefault();
        //}

        public async Task<IReadOnlyList<T>> GetAllAsync()
        {       
          return await _context.Set<T>().ToListAsync();
        }

        public async Task<T> GetByIdAsync(int id)
        {
            return await _context.Set<T>().FindAsync(id);

        }

        //public async Task<T> GetByIdWhitSpecAsync(ISpecification<T> spec)
        //{
        //    return await _context.Set<T>().FindAsync(id);
        //}
    }
}
